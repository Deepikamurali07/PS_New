import os
import subprocess
import sys


def launch_dashboard():
    # Launch the ADDDELETE_1_Excel.py script
    script_path = r"C:\Users\deepi\OneDrive - Aston University\BA\TERM 3\Code\Part_1\Manufacturing_Allocation\MA_Project\ADDDELETE_1_Excel.py"
    subprocess.Popen(['python', script_path])

if __name__ == "__main__":
    # Start the dashboard
    launch_dashboard()
