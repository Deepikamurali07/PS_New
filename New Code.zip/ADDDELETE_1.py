import psycopg2
import dash
from dash import dcc, html, Input, Output, dash_table
from dash.dependencies import Input, Output,State, MATCH, ALL
from datetime import datetime, timedelta
import plotly.express as px
import plotly.graph_objects as go
import pandas as pd
import dash_bootstrap_components as dbc  # Import dash-bootstrap-components
import subprocess
import os
import signal  # Import the signal module
from dash import callback_context
from dash.exceptions import PreventUpdate
from psycopg2 import sql
import threading
import time
import json
import queue
from Allocation_check import output_queue
from multiprocessing import Process, Queue, get_context
import sys
print("Python version")
print(sys.version)
print("Version info.")
print(sys.version_info)

allocation_process=None
# Global variable to track interruption status
allocation_interrupted = False
Dash_time=None
# Database connection details
db_name = 'ProductDetails'
db_username = 'PUser12'
db_password = 'PSQL@123'
db_host = 'localhost'
db_port = '5432'
global flag1
# Function to start allocation process in a separate thread


# Function to fetch data from the database
def fetch_data():
    try:
        conn = psycopg2.connect(
            dbname=db_name,
            user=db_username,
            password=db_password,
            host=db_host,
            port=db_port
        )
        query = '''SELECT * FROM public."prodet";'''
        df = pd.read_sql(query, conn)
        conn.close()
        return df
    except Exception as e:
        print(f"Error fetching data: {e}")
        return pd.DataFrame() 

# Function to fetch data from the database
def fetch_data1():
    try:
        conn = psycopg2.connect(
            dbname=db_name,
            user=db_username,
            password=db_password,
            host=db_host,
            port=db_port
        )
        query = '''SELECT * FROM public."prodet";'''
        df = pd.read_sql(query, conn)
        conn.close()

        # Determine if any component of the product is not editable
        df['editable'] = df.groupby('Product Name')['Status'].transform(lambda x: not any(status in ['Completed', 'InProgress'] for status in x))

        # Filter the dataframe to include only products where all components are editable
        editable_df = df[df['editable']].drop(columns=['editable'])
        print(editable_df)
        return editable_df
        #return df

    except Exception as e:
        print(f"Error fetching data: {e}")
        return pd.DataFrame() 

# Function to convert time string to timedelta
def time_to_timedelta2(t):
    try:
        if isinstance(t, datetime):
            return timedelta(hours=t.hour, minutes=t.minute, seconds=t.second)
        if pd.isna(t) or t == "":
            return timedelta(0)
        # Ensure t is a string and in the format "HH:MM:SS"
        if isinstance(t, str) and ':' in t:
            h, m, s = map(int, t.split(":"))
            return timedelta(hours=h, minutes=m, seconds=s)
        else:
            # Handle unexpected input format or missing ':'
            raise ValueError(f"Unexpected format or missing ':' in input: {t}")
    except Exception as e:
        print(f"Error in time_to_timedelta2: {e}")
        return timedelta(0)  # or raise further or return appropriate default

# Function to calculate utilization in minutes
def calculate_utilization(t):
    total_seconds = t.total_seconds()
    return total_seconds / 60


# Function to fetch previous data from the database
def fetch_previous_data_from_db(db_name, db_username, db_password, db_host, db_port):
    try:
        conn = psycopg2.connect(
            dbname=db_name,
            user=db_username,
            password=db_password,
            host=db_host,
            port=db_port
        )
        
        query = 'SELECT * FROM public."prodet"'
        df = pd.read_sql_query(query, conn)
        conn.close()
        previous_data = df.to_dict('records')
        return previous_data
    except Exception as e:
        print(f"Error fetching data from database: {e}")
        return []
    
# Function to get the last unique ID from the database
def get_last_unique_id(table_name):
    conn = psycopg2.connect(
        dbname=db_name,
        user=db_username,
        password=db_password,
        host=db_host,
        port=db_port
    )
    cursor = conn.cursor()
    if table_name=="prodet":
        query = '''SELECT "UniqueID" FROM public."prodet" ORDER BY "UniqueID" DESC LIMIT 1;'''
    else:
        query = '''SELECT "UniqueID" FROM public."Addln" ORDER BY "UniqueID" DESC LIMIT 1;'''
    cursor.execute(query)
    last_id = cursor.fetchone()
    cursor.close()
    conn.close()
    if last_id:
        return int(last_id[0])
    else:
        return 0  # Return 0 if there are no entries in the database


# Convert necessary fields to string
def convert_data_for_json(data):
    for record in data:
        for key, value in record.items():
            if isinstance(value, pd.Timestamp):
                record[key] = value.strftime('%Y-%m-%d %H:%M:%S')
            elif isinstance(value, (pd.Timedelta, pd.TimedeltaIndex)):
                record[key] = str(value)
            elif pd.isna(value):  # Convert NaN to None for JSON serialization
                record[key] = None
    return data

# Function to connect to PostgreSQL database
def connect_to_database():
    try:
        conn = psycopg2.connect(
            dbname=db_name,
            user=db_username,
            password=db_password,
            host=db_host,
            port=db_port
        )
        return conn
    except Exception as e:
        print(f"Error connecting to database: {e}")
        return None

# Function to fetch data from database for lookup tables
def fetch_data_r(query,key):
    conn = connect_to_database()
    if conn:
        try:
            with conn.cursor() as cursor:
                cursor.execute(query)
                columns = [col[0] for col in cursor.description]
                data = cursor.fetchall()
            return pd.DataFrame(data, columns=columns)
        except Exception as e:
            print(f"Error fetching data: {key}, {e}")
        finally:
            conn.close()
    else:
        print("Database connection not established.")
    return None
   
# Product Lookup Table
product_query = '''SELECT "Product Name", 
       SUM("Quantity Required") AS "Total Quantity Required", 
       COUNT(*) AS "Total Components", 
       ROUND(AVG("Run Time (min/1000)"::numeric),2) AS "Average Run Time" 
FROM public."prodet" 
GROUP BY "Product Name"
ORDER BY "Product Name";'''
product_df = fetch_data_r(product_query,"product")

# Component Lookup Table
component_query = '''SELECT 
                "UniqueID",
                "Product Name", 
                "Order Processing Date", 
                "Promised Delivery Date", 
                "Quantity Required", 
                "Components",
                "Operation",
                "Process Type",
                "Machine Number",
                "Run Time (min/1000)",
                "Start Time",
                "End Time",
                "Status"
            FROM public."prodet";'''
component_df = fetch_data_r(component_query,"comp")

# Machine Utilization Lookup Table
machine_query = '''SELECT "Machine Number", 
       SUM("Run Time (min/1000)"::numeric) AS "Total Runtime", 
       COUNT(*) AS "Total Components", 
       AVG("Cycle Time (seconds)"::numeric) AS "Average Cycle Time" 
FROM public."prodet" 
GROUP BY "Machine Number";'''
machine_df = fetch_data_r(machine_query,"Mach")

# Order Details Lookup Table
order_details_query = '''SELECT "Product Name",
        "Total Time" AS "Total Run Time (mins)",
        "Remaining Time" AS "Remaining Run Time (mins)",
        "Time_Needed" AS "Time Needed (mins)",
        "Time Left" AS "Time Left (mins)",
        "Date" AS "Schedule Date"
FROM public."time_details";'''
order_details_df = fetch_data_r(order_details_query,"Details")

# Function to read data from the Excel sheet and process it
def fetch_similarity_data():
    df = pd.read_excel('Product Details_v1.xlsx', sheet_name='Similarity')
    print(df)
    # Apply transformation: replace 1 with ✓ and leave other cells as is
    df = df.applymap(lambda x: '✓' if x == 1 else ('' if x == 0 else x))
    return df


initial_data = fetch_data1().to_dict('records')
initial_data_json = json.dumps(initial_data, default=str)

# Initialize the starting time to 09:00:00
start_time = datetime.combine(datetime.today(), datetime.min.time()) + timedelta(hours=9)

# Define button style
button_style = {
    'margin': '10px',
    'padding': '15px 30px',
    'font-size': '16px',
    'font-weight': 'bold',
    'border-radius': '8px',
    'background-color': '#3498db',
    'color': 'white',
    'border': 'none',
    'cursor': 'pointer',
    'transition': 'background-color 0.3s ease',
}

app = dash.Dash(__name__, external_stylesheets=[dbc.themes.SLATE])
app.config.suppress_callback_exceptions = True
# Define layout
app.layout = dbc.Container(
    style={'textAlign': 'left', 'width': '100%', 'margin': 'auto'},
    children=[
        html.Div(style={'height': '50px'}),
        html.H1('Dashboard - Production Analysis', style={'textAlign': 'center', 'marginBottom': '30px'}),
        
        dbc.Card(
            id='info-box',
            style={
                'padding': '5px',
                'border': '7px solid #ddd',
                'borderRadius': '15px',
                'backgroundColor': '#3498db',  # Blue color
                'color': 'white',  # Text color
                'textAlign': 'center',  # Center align content inside the box
                'position': 'absolute',
                'left': '20px',
                'top': '25px',
                'width': '250px',  # Adjust width as needed
            },
            children=[
                html.Div(id='live-clock', style={'fontSize': 25, 'textAlign': 'center'}),
                html.Div(id='current-date', style={'fontSize': 18, 'textAlign': 'center'}),
                html.Div(id='current-day', style={'fontSize': 18, 'textAlign': 'center'})
            ]
        ),
        
        dcc.Interval(
            id='interval-component-clock',
            interval=1000,  # Update clock every second
            n_intervals=0
        ),
        
        dcc.Interval(
            id='interval-component-script',
            interval=1000,  # Update script control every second
            n_intervals=0,
            disabled=True  # Start disabled
        ),
        
        dbc.Row([
            dbc.Col([
                html.Button('Read from spreadsheet', id='initialise-button', n_clicks=0, style=button_style),
                html.Button('Run/Reschedule', id='start-button', n_clicks=0, style=button_style),
                html.Button('Pause', id='stop-button', n_clicks=0, style=button_style),
                html.Div(id='start-message', style={'marginLeft': '20px', 'color': 'green'})
            ], width=15, style={'textAlign': 'Right', 'margin': 'auto'})
        ]),
        
        dcc.Tabs(id='tabs', value='tab-input', children=[
            dcc.Tab(label='Product List change', value='tab-manage-products', children=[
                dbc.Row([
                    dbc.Col(
                        dcc.Dropdown(
                            id='manage-dropdown',
                            options=[
                                {'label': 'Add Product', 'value': 'add'},
                                {'label': 'Delete Product', 'value': 'delete'},
                                {'label': 'Swap Product', 'value': 'swap'}
                            ],
                            value='add',
                            placeholder='Select action',
                            style={'width': '200px'}
                        ),
                        width=3,
                        style={'padding': '20px'}
                    ),
                    dbc.Col(
                        html.Div(id='manage-content'),
                        width=9
                    )
                ])
            ]),
            
            dcc.Tab(label='Product Catalogue', value='tab-2', children=[
                html.H2('Below are the product details', style={'textAlign': 'left', 'marginBottom': '30px', 'fontSize': '20px'}),
                html.Div([
                    dash_table.DataTable(
                        id='data-table',
                        columns=[],
                        data=[],
                        filter_action='native',
                        sort_action="native",
                        page_size=10,
                        style_table={'height': '400px', 'overflowY': 'auto', 'marginBottom': '20px'},
                        style_cell={
                            'textAlign': 'center',
                            'padding': '5px',
                            'backgroundColor': '#f9f9f9',
                            'border': '1px solid black',
                            'minWidth': '120px', 'maxWidth': '150px', 'whiteSpace': 'normal'
                        },
                        style_header={
                            'backgroundColor': '#4CAF50',
                            'fontWeight': 'bold',
                            'color': 'white',
                            'border': '1px solid black'
                        },
                        style_data_conditional=[
                            {
                                'if': {'row_index': 'odd'},
                                'backgroundColor': '#f2f2f2',
                            }
                        ],
                        tooltip_data=[
                            {
                                column: {'value': str(value), 'type': 'markdown'}
                                for column, value in row.items()
                            } for row in fetch_data().to_dict('records')
                        ],
                        tooltip_duration=None,
                        css=[{
                            'selector': '.dash-cell div.dash-cell-value',
                            'rule': 'display: inline; white-space: inherit; overflow: inherit; text-overflow: inherit;'
                        }]
                    ),
                    dcc.Interval(
                        id='interval-component-table',
                        interval=5000,
                        n_intervals=0
                    )
                ])
            ]),
            dcc.Tab(label='Similarity Catalogue', value='tab-3', children=[
            html.H2('Below are the similarity details', style={'textAlign': 'left', 'marginBottom': '30px', 'fontSize': '20px'}),
            html.Div([
                dash_table.DataTable(
                    id='similarity-data-table',
                    columns=[{'name': i, 'id': i} for i in fetch_similarity_data().columns],
                    data=fetch_similarity_data().to_dict('records'),
                    filter_action='native',
                    sort_action="native",
                    page_size=10,
                    style_table={'height': '400px', 'overflowY': 'auto', 'marginBottom': '20px'},
                    style_cell={
                        'textAlign': 'center',
                        'padding': '5px',
                        'backgroundColor': '#f9f9f9',
                        'border': '1px solid black',
                        'minWidth': '120px', 'maxWidth': '150px', 'whiteSpace': 'normal'
                    },
                    style_header={
                        'backgroundColor': '#4CAF50',
                        'fontWeight': 'bold',
                        'color': 'white',
                        'border': '1px solid black'
                    },
                    style_data_conditional=[
                        {
                            'if': {'row_index': 'odd'},
                            'backgroundColor': '#f2f2f2',
                        }
                    ],
                    tooltip_data=[
                        {
                            column: {'value': str(value), 'type': 'markdown'}
                            for column, value in row.items()
                        } for row in fetch_similarity_data().to_dict('records')
                    ],
                    tooltip_duration=None,
                    css=[{
                        'selector': '.dash-cell div.dash-cell-value',
                        'rule': 'display: inline; white-space: inherit; overflow: inherit; text-overflow: inherit;'
                    }]
                ),
                dcc.Interval(
                    id='interval-component-similarity-table',
                    interval=5000,
                    n_intervals=0
                )
            ])
        ]),
            
            # Modify Tab
            dcc.Tab(label='Modify', value='tab-modify', children=[
                dcc.Tabs(id='modify-sub-tabs', value='tab-inhouse', children=[
                    dcc.Tab(label='InHouse', value='tab-inhouse', children=[
                        html.Div([
                            html.H2('Modify InHouse Product Data',
                                    style={'textAlign': 'left', 'marginBottom': '20px', 'marginTop': '20px',
                                           'fontSize': '15px'}),

                            dbc.Row([
                                dbc.Col(
                                    dcc.Dropdown(
                                        id='inhouse-product-dropdown',
                                        placeholder='Select Product Name',
                                        style={'marginBottom': '20px'}
                                    ),
                                    width=3
                                ),

                                dbc.Col(
                                    dcc.Dropdown(
                                        id='inhouse-component-dropdown',
                                        placeholder='Select Component',
                                        style={'marginBottom': '20px'}
                                    ),
                                    width=3
                                )
                            ]),

                            dbc.Row([
                                dbc.Col(
                                    dcc.Dropdown(
                                        id='inhouse-column-dropdown',
                                        placeholder='Select field to Edit',
                                        style={'marginBottom': '20px'}
                                    ), width=4
                                )
                            ]),

                            dbc.Row([
                                dbc.Col(
                                    html.Div(id='inhouse-value-container'),
                                    width=6
                                ),
                                dbc.Col(
                                    html.Button('Confirm Changes', id='inhouse-confirm-changes-button', n_clicks=0,
                                                style={'marginTop': '20px'}),
                                    width=6
                                )
                            ]),

                            html.Div(id='inhouse-confirm-message', style={'marginTop': '20px', 'color': 'green',
                                                                           'fontWeight': 'bold'}),

                            # DataTable to display selected data
                            html.Div([
                                dash_table.DataTable(
                                    id='inhouse-selected-data-table',
                                    columns=[
                                        {'name': 'UniqueID', 'id': 'UniqueID'},
                                        {'name': 'Product Name', 'id': 'Product Name'},
                                        {'name': 'Order Processing Date', 'id': 'Order Processing Date'},
                                        {'name': 'Promised Delivery Date', 'id': 'Promised Delivery Date'},
                                        {'name': 'Quantity Required', 'id': 'Quantity Required'},
                                        {'name': 'Components', 'id': 'Components'},
                                        {'name': 'Operation', 'id': 'Operation'},
                                        {'name': 'Process Type', 'id': 'Process Type'},
                                        {'name': 'Machine Number', 'id': 'Machine Number'},
                                        {'name': 'Run Time (min/1000)', 'id': 'Run Time (min/1000)'},
                                        {'name': 'Start Time', 'id': 'Start Time'},
                                        {'name': 'End Time', 'id': 'End Time'},
                                        {'name': 'Status', 'id': 'Status'}
                                    ],
                                    data=[],  # Initially empty until products and components are selected
                                    style_table={'height': '400px', 'overflowY': 'auto'},
                                    style_header={
                                        'backgroundColor': 'rgb(230, 230, 230)',
                                        'fontWeight': 'bold'
                                    },
                                    style_cell={
                                        'textAlign': 'left',
                                        'minWidth': '100px',
                                        'maxWidth': '180px',
                                        'whiteSpace': 'normal'
                                    },
                                    style_data_conditional=[
                                        {
                                            'if': {'row_index': 'odd'},
                                            'backgroundColor': 'rgb(248, 248, 248)'
                                        },
                                        {
                                            'if': {'column_id': 'Status', 'filter_query': '{Status} = "Delayed"'},
                                            'backgroundColor': 'tomato',
                                            'color': 'white',
                                            'fontWeight': 'bold'
                                        }
                                    ],
                                    page_size=10,
                                    sort_action='native',
                                    filter_action='native',
                                    column_selectable='single',
                                    row_selectable='single',
                                    selected_columns=[],
                                    selected_rows=[],
                                    editable=True
                                )
                            ])
                        ])
                    ]),
                    dcc.Tab(label='Outsource', value='tab-outsource', children=[
                        html.Div([
                            html.H2('Modify Outsource Product Data',
                                    style={'textAlign': 'left', 'marginBottom': '20px', 'marginTop': '20px',
                                           'fontSize': '15px'}),

                            dbc.Row([
                                dbc.Col(
                                    dcc.Dropdown(
                                        id='outsource-product-dropdown',
                                        placeholder='Select Product Name',
                                        style={'marginBottom': '20px'}
                                    ),
                                    width=3
                                ),

                                dbc.Col(
                                    dcc.Dropdown(
                                        id='outsource-component-dropdown',
                                        placeholder='Select Component',
                                        style={'marginBottom': '20px'}
                                    ),
                                    width=3
                                )
                            ]),

                            dbc.Row([
                                dbc.Col(
                                    dcc.Dropdown(
                                        id='outsource-column-dropdown',
                                        placeholder='Select field to Edit',
                                        style={'marginBottom': '20px'}
                                    ), width=4
                                )
                            ]),

                            dbc.Row([
                                dbc.Col(
                                    dbc.Input(
                                        id='outsource-value-input',
                                        placeholder='Enter New Value',
                                        type='text',
                                        style={'marginBottom': '20px'}
                                    ),
                                    width=6
                                ),
                                dbc.Col(
                                    html.Button('Confirm Changes', id='outsource-confirm-changes-button', n_clicks=0,
                                                style={'marginTop': '20px'}),
                                    width=6
                                )
                            ]),

                            html.Div(id='outsource-confirm-message', style={'marginTop': '20px', 'color': 'green',
                                                                            'fontWeight': 'bold'}),

                            # DataTable to display selected data
                            html.Div([
                                dash_table.DataTable(
                                    id='outsource-selected-data-table',
                                    columns=[
                                        {'name': 'UniqueID', 'id': 'UniqueID'},
                                        {'name': 'Product Name', 'id': 'Product Name'},
                                        {'name': 'Order Processing Date', 'id': 'Order Processing Date'},
                                        {'name': 'Promised Delivery Date', 'id': 'Promised Delivery Date'},
                                        {'name': 'Quantity Required', 'id': 'Quantity Required'},
                                        {'name': 'Components', 'id': 'Components'},
                                        {'name': 'Operation', 'id': 'Operation'},
                                        {'name': 'Process Type', 'id': 'Process Type'},
                                        {'name': 'Machine Number', 'id': 'Machine Number'},
                                        {'name': 'Run Time (min/1000)', 'id': 'Run Time (min/1000)'},
                                        {'name': 'Start Time', 'id': 'Start Time'},
                                        {'name': 'End Time', 'id': 'End Time'},
                                        {'name': 'Status', 'id': 'Status'}
                                    ],
                                    data=[],  # Initially empty until products and components are selected
                                    style_table={'height': '400px', 'overflowY': 'auto', 'marginBottom': '20px'},
                                    style_header={
                                        'backgroundColor': 'rgb(230, 230, 230)',
                                        'fontWeight': 'bold'
                                    },
                                    style_cell={
                                        'textAlign': 'left',
                                        'minWidth': '100px',
                                        'maxWidth': '180px',
                                        'whiteSpace': 'normal'
                                    },
                                    style_data_conditional=[
                                        {
                                            'if': {'row_index': 'odd'},
                                            'backgroundColor': 'rgb(248, 248, 248)'
                                        },
                                        {
                                            'if': {'column_id': 'Status', 'filter_query': '{Status} = "Delayed"'},
                                            'backgroundColor': 'tomato',
                                            'color': 'white',
                                            'fontWeight': 'bold'
                                        }
                                    ],
                                    page_size=10,
                                    sort_action='native',
                                    filter_action='native',
                                    column_selectable='single',
                                    row_selectable='single',
                                    selected_columns=[],
                                    selected_rows=[],
                                    editable=True
                                )
                            ])
                        ])
                    ])
                ])
            ]),
            
            dcc.Tab(label='Visualize', value='tab-output', children=[
            html.Div(
                "Select a plot to display:",
                style={'textAlign': 'center', 'fontSize': '18px', 'marginTop': '20px'}
            ),
            dcc.Dropdown(
                id='plot-dropdown',
                options=[
                    {'label': 'Gantt Chart', 'value': 'Gantt Chart'},
                    {'label': 'Utilization', 'value': 'Utilization'},
                    {'label': 'Time Taken by each Machine', 'value': 'Time Taken by each Machine'},
                    {'label': 'Time taken by each product', 'value': 'Time taken by each product'},
                    {'label': 'Wait Time', 'value': 'Wait Time'},
                    {'label': 'Idle Time', 'value': 'Idle Time'},
                    {'label': 'Product Components Status', 'value': 'Product Components Status'},
                    {'label': 'Remaining Time', 'value': 'Remaining Time'}
                ],
                value='Gantt Chart',
                style={'width': '50%', 'margin': '15px auto'}
            ),
            html.Div(
                id='graph-container',
                style={'width': '100%', 'height': '600px', 'overflowX': 'auto', 'overflowY': 'auto'},
                children=[
                    dcc.Graph(
                        id='main-graph',
                        style={'width': '100%', 'height': '100%', 'margin': 'auto', 'marginTop': '30px', 'marginBottom': '30px'}
                    ),
                ]
            ),
            dcc.Interval(
                id='interval-component-data',
                interval=5000,  # Update data and chart every 5 seconds (adjust as needed)
                n_intervals=0
            )
    ]),
            dcc.Tab(label='Results', value='tab-results', children=[
    dcc.Tabs(id='results-sub-tabs', value='tab-prod', children=[
    
        # Product Tab
        dcc.Tab(label='Product', value='tab-product', children=[
            html.Div([
                dash_table.DataTable(
                    id='product-table',
                    columns=[{"name": i, "id": i} for i in (product_df.columns if product_df is not None else [])],
                    data=product_df.to_dict('records') if product_df is not None else [],
                    style_table={'overflowX': 'auto'},
                    style_cell={
                        'minWidth': '100px', 'width': '150px', 'maxWidth': '300px',
                        'whiteSpace': 'normal',
                        'textAlign': 'center'
                    },
                    style_header={
                        'backgroundColor': 'rgb(230, 230, 230)',
                        'fontWeight': 'bold'
                    },
                    style_data_conditional=[
                        {
                            'if': {'row_index': 'odd'},
                            'backgroundColor': 'rgb(248, 248, 248)'
                        },
                    ],
                    page_size=10,  # Adjust as needed
                ) if product_df is not None else html.Div("No data available.", style={'textAlign': 'center'})
            ])
        ]),
        
        # Machine Utilization Tab
        dcc.Tab(label='Machine Utilization', value='tab-machine', children=[
            html.Div([
                dash_table.DataTable(
                    id='machine-table',
                    columns=[{"name": i, "id": i} for i in (machine_df.columns if machine_df is not None else [])],
                    data=machine_df.to_dict('records') if machine_df is not None else [],
                    style_table={'overflowX': 'auto'},
                    style_cell={
                        'minWidth': '100px', 'width': '150px', 'maxWidth': '300px',
                        'whiteSpace': 'normal',
                        'textAlign': 'center'
                    },
                    style_header={
                        'backgroundColor': 'rgb(230, 230, 230)',
                        'fontWeight': 'bold'
                    },
                    style_data_conditional=[
                        {
                            'if': {'row_index': 'odd'},
                            'backgroundColor': 'rgb(248, 248, 248)'
                        },
                    ],
                    page_size=10,  # Adjust as needed
                ) if machine_df is not None else html.Div("No data available.", style={'textAlign': 'center'})
            ])
        ]),
        # Order Details Tab
        dcc.Tab(label='Product Details', value='tab-component', children=[
            html.Div([
                dash_table.DataTable(
                    id='component-table',
                    columns=[{"name": i, "id": i} for i in (component_df.columns if component_df is not None else [])],
                    data=component_df.to_dict('records') if component_df is not None else [],
                    style_table={'overflowX': 'auto'},
                    style_cell={
                        'minWidth': '100px', 'width': '150px', 'maxWidth': '300px',
                        'whiteSpace': 'normal',
                        'textAlign': 'center'
                    },
                    style_header={
                        'backgroundColor': '#f2f2f2',
                        'fontWeight': 'bold',
                        'border': '1px solid black'
                    },
                    style_data_conditional=[
                        {
                            'if': {'row_index': 'odd'},
                            'backgroundColor': 'rgb(248, 248, 248)'
                        },
                    ],
                    page_size=10,  # Adjust as needed
                ) if component_df is not None else html.Div("No data available.", style={'textAlign': 'center'})
            ])
        ]),
        # Order Details Tab
        dcc.Tab(label='Scheduling Details', value='tab-order-details', children=[
            html.Div([
                dash_table.DataTable(
                    id='order-details-table',
                    columns=[{"name": i, "id": i} for i in (order_details_df.columns if order_details_df is not None else [])],
                    data=order_details_df.to_dict('records') if order_details_df is not None else [],
                    style_table={'overflowX': 'auto'},
                    style_cell={
                        'minWidth': '100px', 'width': '150px', 'maxWidth': '300px',
                        'whiteSpace': 'normal',
                        'textAlign': 'center'
                    },
                    style_header={
                        'backgroundColor': '#f2f2f2',
                        'fontWeight': 'bold',
                        'border': '1px solid black'
                    },
                    style_data_conditional=[
                        {
                            'if': {'row_index': 'odd'},
                            'backgroundColor': 'rgb(248, 248, 248)'
                        },
                    ],
                    page_size=10,  # Adjust as needed
                ) if order_details_df is not None else html.Div("No data available.", style={'textAlign': 'center'})
            ])
        ]),
    ]),
]),

        ], style={'width': '100%','marginTop': '50px', 'marginBottom': '50px'})
    ]
)

@app.callback(
    Output('manage-content', 'children'),
    Input('manage-dropdown', 'value')
)
def render_manage_content(action):
    if action == 'add':
        return html.Div(
            id='input-form',
            children=[
                html.H2('Add New Product', style={'textAlign': 'left', 'marginBottom': '30px', 'fontSize': '20px'}),
                dbc.InputGroup(
                    [
                        dbc.InputGroupText("Sr. No:"),
                        dbc.Input(id='Sr-No', type='number', placeholder='Enter product number (Product 1, Product 2, ...)'),
                    ],
                    style={'marginBottom': '10px'}
                ),
                dbc.InputGroup(
                    [
                        dbc.InputGroupText("Product Name:"),
                        dbc.Input(id='Product-Name', type='text', placeholder='Enter product name'),
                    ],
                    style={'marginBottom': '10px'}
                ),
                dbc.InputGroup(
                    [
                        dbc.InputGroupText("Order Processing Date:"),
                        dbc.Input(id='Order-Processing-Date', type='date', placeholder='Enter processing date'),
                    ],
                    style={'marginBottom': '10px'}
                ),
                dbc.InputGroup(
                    [
                        dbc.InputGroupText("Promised Delivery Date:"),
                        dbc.Input(id='Promised-Delivery-Date', type='date', placeholder='Enter delivery date'),
                    ],
                    style={'marginBottom': '10px'}
                ),
                dbc.InputGroup(
                    [
                        dbc.InputGroupText("Quantity Required:"),
                        dbc.Input(id='Quantity-Required', type='number', placeholder='Enter required quantity'),
                    ],
                    style={'marginBottom': '10px'}
                ),
                dbc.InputGroup(
                    [
                        dbc.InputGroupText("Components:"),
                        dbc.Input(id='Components', type='text', placeholder='Enter components'),
                    ],
                    style={'marginBottom': '10px'}
                ),
                dbc.InputGroup(
                    [
                        dbc.InputGroupText("Operation:"),
                        dbc.Input(id='Operation', type='text', placeholder='Enter operation'),
                    ],
                    style={'marginBottom': '10px'}
                ),
                dbc.InputGroup(
                            [
                                dbc.InputGroupText("Process Type:"),
                                dcc.Dropdown(
                                    id='Process-Type',
                                    options=[
                                        {'label': 'In House', 'value': 'In House'},
                                        {'label': 'Outsource', 'value': 'Outsource'}
                                    ],
                                    placeholder='Select process type...',
                                    style={'width': '70%'}  # Adjust width as needed
                                ),
                            ],
                            style={'marginBottom': '10px'}
                        ),
                dbc.InputGroup(
                    [
                        dbc.InputGroupText("Machine Number:"),
                        dbc.Input(id='Machine-Number', type='text', placeholder='Enter machine number'),
                    ],
                    style={'marginBottom': '10px'}
                ),
                dbc.InputGroup(
                    [
                        dbc.InputGroupText("Run Time (min/1000):"),
                        dbc.Input(id='Run-Time', type='number', placeholder='Enter run time'),
                    ],
                    style={'marginBottom': '10px'}
                ),
                dbc.InputGroup(
                    [
                        dbc.InputGroupText("Cycle Time (seconds):"),
                        dbc.Input(id='Cycle-Time', type='number', placeholder='Enter cycle time'),
                    ],
                    style={'marginBottom': '10px'}
                ),
                dbc.InputGroup(
                    [
                        dbc.InputGroupText("Setup time (seconds):"),
                        dbc.Input(id='Setup-Time', type='number', placeholder='Enter setup time'),
                    ],
                    style={'marginBottom': '10px'}
                ),
                html.Button('Submit', id='submit-button', n_clicks=0, style={'marginTop': '10px'}),
                html.Div(id='submit-output', style={'marginTop': '10px'})
            ]
        )

    elif action == 'delete':
        return html.Div(
            id='input-form',
            children=[
                html.H2('Delete Product', style={'textAlign': 'left', 'marginBottom': '30px', 'fontSize': '20px'}),
                dbc.InputGroup(
                    [
                        dbc.InputGroupText("UniqueID:"),
                        dbc.Input(id='UniqueID-delete', type='number', placeholder='Enter UniqueID to delete'),
                    ],
                    style={'marginBottom': '10px'}
                ),
                html.Button('Delete', id='delete-button', n_clicks=0, style={'marginTop': '10px'}),
                html.Div(id='delete-output', style={'marginTop': '10px'})
            ]
        )

    elif action == 'swap':
        return html.Div(
            id='input-form',
            children=[
                html.H2('Swap Product', style={'textAlign': 'left', 'marginBottom': '30px', 'fontSize': '20px'}),
                dbc.InputGroup(
                    [
                        dbc.InputGroupText("First UniqueID:"),
                        dbc.Input(id='UniqueID-swap1', type='number', placeholder='Enter first UniqueID'),
                    ],
                    style={'marginBottom': '10px'}
                ),
                dbc.InputGroup(
                    [
                        dbc.InputGroupText("Second UniqueID:"),
                        dbc.Input(id='UniqueID-swap2', type='number', placeholder='Enter second UniqueID'),
                    ],
                    style={'marginBottom': '10px'}
                ),
                html.Button('Swap', id='swap-button', n_clicks=0, style={'marginTop': '10px'}),
                html.Div(id='swap-output', style={'marginTop': '10px'})
            ]
        )

    else:
        return html.Div()


# Callback to add new product
@app.callback(
    Output('submit-output', 'children'),
    Input('submit-button', 'n_clicks'),
    State('Sr-No', 'value'),
    State('Product-Name', 'value'),
    State('Order-Processing-Date', 'value'),
    State('Promised-Delivery-Date', 'value'),
    State('Quantity-Required', 'value'),
    State('Components', 'value'),
    State('Operation', 'value'),
    State('Process-Type', 'value'),
    State('Machine-Number', 'value'),
    State('Run-Time', 'value'),
    State('Cycle-Time', 'value'),
    State('Setup-Time', 'value')
)
def add_new_product(n_clicks, sr_no, product_name, processing_date, delivery_date, quantity_required,
                    components, operation, process_type, machine_number, run_time, cycle_time, setup_time):
    if n_clicks > 0:
        try:
            # Check if "Addln" table is empty
            conn = psycopg2.connect(
                dbname=db_name,
                user=db_username,
                password=db_password,
                host=db_host,
                port=db_port
            )
            cursor = conn.cursor()
            cursor.execute("SELECT COUNT(*) FROM public.\"Addln\"")
            addln_count = cursor.fetchone()[0]

            if addln_count == 0:
                # If "Addln" table is empty, get last ID from "prodet"
                last_id = get_last_unique_id("prodet")
            else:
                # Otherwise, get last ID from "Addln"
                last_id = get_last_unique_id("Addln")

            new_id = last_id + 1  # Increment the last ID by 1

            cursor.close()
            conn.close()

            conn = psycopg2.connect(
                dbname=db_name,
                user=db_username,
                password=db_password,
                host=db_host,
                port=db_port
            )
            cursor = conn.cursor()

            cursor.execute('INSERT INTO public."Addln" ( "UniqueID","Sr. No", "Product Name", "Order Processing Date", \
                            "Promised Delivery Date", "Quantity Required", "Components", "Operation", \
                            "Process Type", "Machine Number", "Run Time (min/1000)", "Cycle Time (seconds)", \
                            "Setup time (seconds)") VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)',
                           (new_id, sr_no, product_name, processing_date, delivery_date, quantity_required,
                            components, operation, process_type, machine_number, run_time, cycle_time, setup_time))
            conn.commit()

            cursor.close()
            conn.close()

            return dbc.Alert("Product added successfully", color="success", dismissable=True)

        except Exception as e:
            return dbc.Alert(f"Error adding product: {e}", color="danger", dismissable=True)

    return html.Div()


# Callback to delete product
@app.callback(
    Output('delete-output', 'children'),
    Input('delete-button', 'n_clicks'),
    State('UniqueID-delete', 'value')
)
def delete_product(n_clicks, unique_id):
    if n_clicks > 0:
        try:
            conn = psycopg2.connect(
                dbname=db_name,
                user=db_username,
                password=db_password,
                host=db_host,
                port=db_port
            )
            cursor = conn.cursor()

            cursor.execute('DELETE FROM public."prodet" WHERE "UniqueID" = %s', (unique_id,))
            conn.commit()

            cursor.close()
            conn.close()

            return dbc.Alert("Product deleted successfully", color="success", dismissable=True)

        except Exception as e:
            return dbc.Alert(f"Error deleting product: {e}", color="danger", dismissable=True)

    return html.Div()


# Callback to swap products
@app.callback(
    Output('swap-output', 'children'),
    Input('swap-button', 'n_clicks'),
    State('UniqueID-swap1', 'value'),
    State('UniqueID-swap2', 'value')
)
def swap_products(n_clicks, unique_id1, unique_id2):
    if n_clicks > 0:
        try:
            conn = psycopg2.connect(
                dbname=db_name,
                user=db_username,
                password=db_password,
                host=db_host,
                port=db_port
            )
            cursor = conn.cursor()
            query1 = '''SELECT * FROM public."prodet" WHERE "UniqueID" = %s'''
            query2 = '''SELECT * FROM public."prodet" WHERE "UniqueID" = %s'''
            cursor.execute(query1, (unique_id1,))
            product1 = cursor.fetchone()
            cursor.execute(query2, (unique_id2,))
            product2 = cursor.fetchone()
            if product1 and product2:
                query3 = '''UPDATE public."prodet" SET "Sr. No" = %s, "Product Name" = %s, "Order Processing Date" = %s, "Promised Delivery Date" = %s, "Quantity Required" = %s,
                "Components" = %s, "Operation" = %s, "Process Type" = %s, "Machine Number" = %s, "Run Time (min/1000)" = %s, "Cycle Time (seconds)" = %s, "Setup time (seconds)" = %s
                WHERE "UniqueID" = %s'''
                cursor.execute(query3, (product2[1], product2[2], product2[3], product2[4], product2[5], product2[6], product2[7], product2[8], product2[9], product2[10], product2[11], product2[12], unique_id1))
                cursor.execute(query3, (product1[1], product1[2], product1[3], product1[4], product1[5], product1[6], product1[7], product1[8], product1[9], product1[10], product1[11], product1[12], unique_id2))
                conn.commit()
                cursor.close()
                conn.close()
                return f'Products with Unique IDs {unique_id1} and {unique_id2} swapped successfully!'
            else:
                return 'One or both products not found!'

        except Exception as e:
            return dbc.Alert(f"Error swapping products: {e}", color="danger", dismissable=True)

    return html.Div()


def fetch_data_Details1(product_name=None, component_name=None):
    try:
        conn = psycopg2.connect(
            dbname=db_name,
            user=db_username,
            password=db_password,
            host=db_host,
            port=db_port
        )
        query = '''
            SELECT 
                "UniqueID",
                "Product Name", 
                "Order Processing Date", 
                "Promised Delivery Date", 
                "Quantity Required", 
                "Components",
                "Operation",
                "Process Type",
                "Machine Number",
                "Run Time (min/1000)",
                "Start Time",
                "End Time",
                "Status"
            FROM public."prodet"
            ORDER BY "UniqueID";
        '''
        
        
        df = pd.read_sql(query, conn)

        conn.close()
        return df
    except Exception as e:
        print(f"Error fetching data: {e}")
        return pd.DataFrame()

@app.callback(
    Output('data-table', 'columns'),
    Output('data-table', 'data'),
    Input('interval-component-table', 'n_intervals')
)
def update_table(n_intervals):
    df = fetch_data_Details1()
    columns = [{'name': col, 'id': col} for col in df.columns]
    data = df.to_dict('records')
    return columns, data


# Sample function to fetch data from the database
def fetch_data_Details(product_name=None, component_name=None):
    try:
        conn = psycopg2.connect(
            dbname='ProductDetails',
            user='PUser12',
            password='PSQL@123',
            host='localhost',
            port='5432'
        )
        query = '''
            SELECT 
                "UniqueID",
                "Product Name", 
                "Order Processing Date", 
                "Promised Delivery Date", 
                "Quantity Required", 
                "Components",
                "Operation",
                "Process Type",
                "Machine Number",
                "Run Time (min/1000)",
                "Start Time",
                "End Time",
                "Status"
            FROM public."prodet"
        '''
        
        if product_name and component_name:
            query += ' WHERE "Product Name" = %s AND "Components" = %s'
            df = pd.read_sql(query, conn, params=(product_name, component_name))
        elif product_name:
            query += ' WHERE "Product Name" = %s'
            df = pd.read_sql(query, conn, params=(product_name,))
        elif component_name:
            query += ' WHERE "Components" = %s'
            df = pd.read_sql(query, conn, params=(component_name,))
        else:
            df = pd.read_sql(query, conn)

        conn.close()
        return df
    except Exception as e:
        print(f"Error fetching data: {e}")
        return pd.DataFrame()

# Sample function to modify database records
def modify_DB(unique_id, column_name, new_value):
    try:
        conn = psycopg2.connect(
            dbname='ProductDetails',
            user='PUser12',
            password='PSQL@123',
            host='localhost',
            port='5432'
        )
        cursor = conn.cursor()
        
        # Perform update based on unique_id, column_name, and new_value
        query = sql.SQL('UPDATE public."prodet" SET {} = %s WHERE "UniqueID" = %s').format(sql.Identifier(column_name))
        cursor.execute(query, (new_value, unique_id))
        
        conn.commit()
        cursor.close()
        conn.close()
        return True
    except Exception as e:
        print(f"Error updating database: {e}")
        return False

# Function to fetch product names and components based on process type
def fetch_products_and_components(process_type):
    try:
        conn = psycopg2.connect(
            dbname='ProductDetails',
            user='PUser12',
            password='PSQL@123',
            host='localhost',
            port='5432'
        )
        cursor = conn.cursor()

        cursor.execute('SELECT DISTINCT "Product Name" FROM public."prodet" WHERE "Process Type" = %s', (process_type,))
        product_names = [row[0] for row in cursor.fetchall()]
        cursor.execute('SELECT DISTINCT "Components" FROM public."prodet" WHERE "Process Type" = %s', (process_type,))
        components = [row[0] for row in cursor.fetchall()]

        cursor.close()
        conn.close()

        return product_names, components
    except Exception as e:
        print(f"Error fetching products and components: {e}")
        return [], []

# Function to fetch UniqueID based on product name, component, and process type
def fetch_unique_id(product_name, component, process_type):
    try:
        conn = psycopg2.connect(
            dbname='ProductDetails',
            user='PUser12',
            password='PSQL@123',
            host='localhost',
            port='5432'
        )
        cursor = conn.cursor()
        
        query = '''
            SELECT "UniqueID"
            FROM public."prodet"
            WHERE "Product Name" = %s AND "Components" = %s AND "Process Type" = %s
        '''
        cursor.execute(query, (product_name, component, process_type))
        result = cursor.fetchone()
        
        cursor.close()
        conn.close()
        
        if result:
            return result[0]
        else:
            return None
    except Exception as e:
        print(f"Error fetching UniqueID: {e}")
        return None



# Callback to render content based on tab selection
@app.callback(
    Output('tabs-content', 'children'),
    Input('modify-sub-tabs', 'value')
)
def render_tab_content(tab):
    if tab == 'tab-inhouse':
        return html.Div([
            dcc.Dropdown(id='inhouse-product-dropdown', placeholder='Select Product'),
            dcc.Dropdown(id='inhouse-component-dropdown', placeholder='Select Component'),
            dcc.Dropdown(id='inhouse-column-dropdown', placeholder='Select Column'),
            html.Div(id='inhouse-value-container'),
            html.Button('Confirm Changes', id='inhouse-confirm-changes-button'),
            html.Div(id='inhouse-confirm-message'),
            dash_table.DataTable(id='inhouse-selected-data-table', columns=[{'name': col, 'id': col} for col in ['Product Name', 'Components', 'Order Processing Date', 'Promised Delivery Date']], data=[]),
        ])
    elif tab == 'tab-outsource':
        return html.Div([
            dcc.Dropdown(id='outsource-product-dropdown', placeholder='Select Product'),
            dcc.Dropdown(id='outsource-component-dropdown', placeholder='Select Component'),
            dcc.Dropdown(id='outsource-column-dropdown', placeholder='Select Column'),
            dbc.Input(id='outsource-value-input', placeholder='Enter New Value', type='text'),
            html.Button('Confirm Changes', id='outsource-confirm-changes-button'),
            html.Div(id='outsource-confirm-message'),
            dash_table.DataTable(id='outsource-selected-data-table', columns=[{'name': col, 'id': col} for col in ['Product Name', 'Components', 'Run Time (min/1000)']], data=[]),
        ])
    else:
        return html.Div()

# Callback to update product dropdown options for InHouse
@app.callback(
    Output('inhouse-product-dropdown', 'options'),
    Input('modify-sub-tabs', 'value')
)
def update_inhouse_product_dropdown(tab):
    if tab != 'tab-inhouse':
        raise dash.exceptions.PreventUpdate
    
    product_names, _ = fetch_products_and_components('In House')
    
    options = [{'label': name, 'value': name} for name in product_names]
    
    return options

# Callback to update component dropdown options for InHouse based on selected product
@app.callback(
    Output('inhouse-component-dropdown', 'options'),
    Input('inhouse-product-dropdown', 'value')
)
def update_inhouse_component_dropdown(product_name):
    if product_name is None:
        raise dash.exceptions.PreventUpdate
    
    conn = None
    try:
        conn = psycopg2.connect(
            dbname='ProductDetails',
            user='PUser12',
            password='PSQL@123',
            host='localhost',
            port='5432'
        )
        cursor = conn.cursor()
        
        query = '''
            SELECT DISTINCT "Components"
            FROM public."prodet"
            WHERE "Product Name" = %s AND "Process Type" = 'In House'
        '''
        cursor.execute(query, (product_name,))
        components = [row[0] for row in cursor.fetchall()]
        
        cursor.close()
        return [{'label': comp, 'value': comp} for comp in components]
    
    except Exception as e:
        print(f"Error fetching components: {e}")
        return []
    finally:
        if conn is not None:
            conn.close()

# Callback to update column dropdown options for InHouse
@app.callback(
    Output('inhouse-column-dropdown', 'options'),
    Input('inhouse-product-dropdown', 'value'),
    Input('inhouse-component-dropdown', 'value')
)
def update_inhouse_column_dropdown(product_name, component_name):
    if product_name is None or component_name is None:
        raise dash.exceptions.PreventUpdate
    
    columns = ['Product Name', 'Order Processing Date', 'Promised Delivery Date', 'Quantity Required', 'Components', 'Operation', 'Process Type', 'Machine Number', 'Run Time (min/1000)', 'Cycle Time (seconds)', 'Setup time (seconds)']
    
    return [{'label': col, 'value': col} for col in columns]

# Callback to render input type based on selected column in InHouse tab
@app.callback(
    Output('inhouse-value-container', 'children'),
    Input('inhouse-column-dropdown', 'value')
)
def render_inhouse_value_input(column_selected):
    if column_selected is None:
        return html.Div()
    if column_selected in ['Order Processing Date', 'Promised Delivery Date']:
        return html.Div([
            dcc.DatePickerSingle(
                id={'type': 'dynamic-date-picker', 'index': column_selected + '-date'},
                display_format='YYYY-MM-DD',
                style={'marginBottom': '20px'}
            ),
            dcc.Input(
                id={'type': 'dynamic-time-picker', 'index': column_selected + '-time'},
                type='text',
                placeholder='Select Time (HH:MM:SS)',
                style={'marginBottom': '20px'}
            )
        ])
    else:
        return dbc.Input(
            id={'type': 'dynamic-input', 'index': column_selected},
            placeholder='Enter New Value',
            type='text',
            style={'marginBottom': '20px'}
        )
def get_time_from_input(column_name,time_str):
    try:
        print(time_str)
        hours, minutes = map(int, time_str.split(':'))
        return time(hours, minutes)
    except ValueError:
        return None


# Callback to handle confirmation of changes in InHouse tab
@app.callback(
    Output('inhouse-confirm-message', 'children'),
    Input('inhouse-confirm-changes-button', 'n_clicks'),
    State('inhouse-product-dropdown', 'value'),
    State('inhouse-component-dropdown', 'value'),
    State('inhouse-column-dropdown', 'value'),
    State({'type': 'dynamic-input', 'index': ALL}, 'value'),
    State({'type': 'dynamic-date-picker', 'index': ALL}, 'date'),
    State({'type': 'dynamic-time-picker', 'index': ALL}, 'value'),
)
def update_inhouse_database(n_clicks, product_name, component_name, column_name, new_values, date_values,time_values):
    try: 
        if n_clicks == 0 or product_name is None or component_name is None or column_name is None:
            raise dash.exceptions.PreventUpdate
        print(f"new_values: {new_values}")
        print(f"date_values: {date_values}")
        print(f"Column Selected: {column_name}")
        print(f"Time: {time_values}")
        if not all(new_values) and not all(date_values):
            return "Please fill all fields."
        
        db_name = 'ProductDetails'
        db_username = 'PUser12'
        db_password = 'PSQL@123'
        db_host = 'localhost'
        db_port = '5432'
        
        unique_id = fetch_unique_id(product_name, component_name, 'In House')
        #print(unique_id)
        success_messages = []
        #print(new_values)
        
        for idx, value in enumerate(new_values):
            print(f"value: {value}")
            if value:
                success = modify_DB(unique_id, column_name, value)
                if success:
                    success_messages.append(f"Successfully updated {column_name} to {value}.")
        for idx, date_val in enumerate(date_values):
            if date_val:
                #time_val = get_time_from_input(column_name,time_values)  # Extract time from input
                time_val=time_values[0]
                print(f"Date Value: {date_val}")
                print(f"Time Value: {time_val}")
                if time_val:
                    #datetime_val = datetime.combine(date_val, time_val)
                    datetime_str = f'{date_val}T{time_val}'
                    print(datetime_str)
                    success = modify_DB(unique_id, column_name, datetime_str)
                    if success:
                        success_messages.append(f"Successfully updated {column_name} to {datetime_str}.")
                else:
                    success = modify_DB(unique_id, column_name, date_val)
                    if success:
                        success_messages.append(f"Successfully updated {column_name} to {date_val}.")
        
        if success_messages:
            return html.Div([html.P(msg) for msg in success_messages])
        else:
            return "Error updating database. Please try again."
    except Exception as e:
        print(f"Error in update_inhouse_database: {e}")
# Callback to update product dropdown options for Outsource
@app.callback(
    Output('outsource-product-dropdown', 'options'),
    Input('modify-sub-tabs', 'value')
)
def update_outsource_product_dropdown(tab):
    if tab != 'tab-outsource':
        raise dash.exceptions.PreventUpdate
    
    product_names, _ = fetch_products_and_components('Outsource')
    
    options = [{'label': name, 'value': name} for name in product_names]
    
    return options

# Callback to update component dropdown options for Outsource based on selected product
@app.callback(
    Output('outsource-component-dropdown', 'options'),
    Input('outsource-product-dropdown', 'value')
)
def update_outsource_component_dropdown(product_name):
    if product_name is None:
        raise dash.exceptions.PreventUpdate
    
    conn = None
    try:
        conn = psycopg2.connect(
            dbname='ProductDetails',
            user='PUser12',
            password='PSQL@123',
            host='localhost',
            port='5432'
        )
        cursor = conn.cursor()
        
        query = '''
            SELECT DISTINCT "Components"
            FROM public."prodet"
            WHERE "Product Name" = %s AND "Process Type" = 'Outsource'
        '''
        cursor.execute(query, (product_name,))
        components = [row[0] for row in cursor.fetchall()]
        
        cursor.close()
        return [{'label': comp, 'value': comp} for comp in components]
    
    except Exception as e:
        print(f"Error fetching components: {e}")
        return []
    finally:
        if conn is not None:
            conn.close()

# Callback to update column dropdown options for Outsource
@app.callback(
    Output('outsource-column-dropdown', 'options'),
    Input('outsource-product-dropdown', 'value'),
    Input('outsource-component-dropdown', 'value')
)
def update_outsource_column_dropdown(product_name, component_name):
    if product_name is None or component_name is None:
        raise dash.exceptions.PreventUpdate
    
    columns = ['Run Time (min/1000)']
    
    return [{'label': col, 'value': col} for col in columns]

# Callback to handle confirmation of changes in Outsource tab
@app.callback(
    Output('outsource-confirm-message', 'children'),
    Input('outsource-confirm-changes-button', 'n_clicks'),
    State('outsource-product-dropdown', 'value'),
    State('outsource-component-dropdown', 'value'),
    State('outsource-column-dropdown', 'value'),
    State('outsource-value-input', 'value')
)
def update_outsource_database(n_clicks, product_name, component_name, column_name, new_value):
    if n_clicks == 0 or product_name is None or component_name is None or column_name is None:
        raise dash.exceptions.PreventUpdate
    
    if new_value is None:
        return "Please fill all fields."
    
    db_name = 'ProductDetails'
    db_username = 'PUser12'
    db_password = 'PSQL@123'
    db_host = 'localhost'
    db_port = '5432'
    
    unique_id = fetch_unique_id(product_name, component_name, 'Outsource')
    success = modify_DB(unique_id, column_name, new_value)
    
    if success:
        return f"Successfully updated {column_name} to {new_value}."
    else:
        return "Error updating database. Please try again."

# Callback to update the data table based on product and component selection for InHouse
@app.callback(
    Output('inhouse-selected-data-table', 'data'),
    Input('inhouse-product-dropdown', 'value'),
    Input('inhouse-component-dropdown', 'value')
)
def update_inhouse_selected_data_table(product_name, component_name):
    if product_name and component_name:
        df = fetch_data_Details(product_name, component_name)
        return df.to_dict('records')
    else:
        return []

# Callback to update the data table based on product and component selection for Outsource
@app.callback(
    Output('outsource-selected-data-table', 'data'),
    Input('outsource-product-dropdown', 'value'),
    Input('outsource-component-dropdown', 'value')
)
def update_outsource_selected_data_table(product_name, component_name):
    if product_name and component_name:
        df = fetch_data_Details(product_name, component_name)
        return df.to_dict('records')
    else:
        return []



# Function to read the stdout and stderr
def read_output(process):
    try:
        for stdout_line in iter(process.stdout.readline, b''):
            if stdout_line:
                print(stdout_line.decode().strip())
        process.stdout.close()
    except Exception as e:
        print(f"Error reading stdout: {e}")

    try:
        for stderr_line in iter(process.stderr.readline, b''):
            if stderr_line:
                print(f"ERROR: {stderr_line.decode().strip()}")
        process.stderr.close()
    except Exception as e:
        print(f"Error reading stderr: {e}")

def start_allocation_check(keyword):
    global allocation_process
    
    try:
        allocation_process = subprocess.Popen(
            ['python', 'Allocation_check.py'],
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            bufsize=1  # Line-buffered mode
        )
        stdout, stderr = allocation_process.communicate(keyword)
        #print("Script output:", stdout)
        #print("Script error:", stderr)
        threading.Thread(target=read_output, args=(allocation_process,), daemon=True).start()
        print("Allocation_check.py started successfully")
    except Exception as e:
        print(f"Error starting Allocation_check.py: {e}")
        raise
        


# Function to stop the execution of the external script
def stop_allocation_check():
    global allocation_process
    if allocation_process and allocation_process.poll() is None:
        allocation_process.terminate()
        allocation_process = None



@app.callback(
    [Output('interval-component-script', 'disabled'),
     Output('start-message', 'children')],
    [Input('initialise-button', 'n_clicks'),
     Input('start-button', 'n_clicks'),
     Input('stop-button', 'n_clicks')],
    [State('interval-component-script', 'disabled')]
)
def control_allocation_check(initialise_clicks, start_clicks, stop_clicks, interval_disabled):
    ctx = dash.callback_context
    if not ctx.triggered:
        return interval_disabled, None
    
    triggered_id = ctx.triggered[0]['prop_id'].split('.')[0]
    message = ""
    
    if triggered_id == 'initialise-button' and initialise_clicks:
        try:
            start_allocation_check("Initial")
            interval_disabled = False
            message = "Initialization process started."
        except Exception as e:
            message = f"Error starting initialization process: {str(e)}"
    elif triggered_id == 'start-button' and start_clicks:
        try:
            start_allocation_check("Start")
            interval_disabled = False
            message = "Program started successfully."
        except Exception as e:
            message = f"Error starting program: {str(e)}"
    elif triggered_id == 'stop-button' and stop_clicks:
        try:
            stop_allocation_check()
            interval_disabled = True
            message = "Program stopped."
        except Exception as e:
            message = f"Error stopping program: {str(e)}"
    print(message)
    return interval_disabled, message




def fetch_latest_completed_time():
    # Establish the database connection
    conn = psycopg2.connect(
        dbname="ProductDetails",
        user="PUser12",
        password="PSQL@123",
        host="localhost",
        port="5432"
    )
    cursor = conn.cursor()
    
    try:
        # Fetch the latest 'End Time' from the 'prodet' table where Status is 'Completed'
        query = sql.SQL('SELECT MAX("End Time") FROM {schema}.{table} WHERE "Status" = %s').format(
            schema=sql.Identifier('public'),
            table=sql.Identifier('prodet')
        )
        cursor.execute(query, ('Completed',))
        latest_end_time = cursor.fetchone()[0]

        # If there is a completed product, return its end time
        if latest_end_time:
            return latest_end_time
        else:
            return None
    except Exception as e:
        print(f"Error fetching latest completed time: {e}")
        return None
    finally:
        cursor.close()
        conn.close()
# Function to fetch data from the database
def fetch_data_runtime():
    try:
        conn = psycopg2.connect(
            dbname=db_name,
            user=db_username,
            password=db_password,
            host=db_host,
            port=db_port
        )
        query = '''SELECT * FROM public."RunTime";'''
        with conn.cursor() as cursor:
            cursor.execute(query)
            run_time = cursor.fetchone()[0]
            #print(run_time)
            if run_time is None:
                run_time1 = 0  # Default value if no run_time is found
            else:
                run_time1 = float(run_time) 
            
            conn.commit()

        conn.close()
        return run_time1
        
    except Exception as e:
        print(f"Error fetching data: {e}")
        
# Assume this is your global start_time initialized somewhere in your app
#Dash_time = datetime.now().replace(hour=9, minute=0, second=0, microsecond=0)  # Example start time
#Dash_time = datetime.now()
# Function to fetch data from the database
def update_data_runtime():
    try:
        conn = psycopg2.connect(
            dbname=db_name,
            user=db_username,
            password=db_password,
            host=db_host,
            port=db_port
        )
        # Set the runtime data to NULL
        update_query = '''UPDATE public."RunTime" SET "Run_time" = NULL;'''
            
        with conn.cursor() as cursor:
            cursor.execute(update_query)
            
            
            
            conn.commit()

        conn.close()
        
        
    except Exception as e:
        print(f"Error updating data: {e}")
        
# Callback to update the live clock and date
@app.callback(
    Output('live-clock', 'children'),
    Output('current-date', 'children'),
    Output('current-day', 'children'),
    Input('interval-component-clock', 'n_intervals')
)
def update_clock(n):
    global Dash_time
    
    if Dash_time is None:
        Dash_time = datetime.now().replace(hour=9, minute=0, second=0, microsecond=0)
        #continue
    run_time_minutes = fetch_data_runtime()
    end_of_day = Dash_time.replace(hour=17, minute=0, second=0, microsecond=0)
    run_time = timedelta(minutes=run_time_minutes)
    work_start_hour = 9
    work_end_hour = 17
    

    if run_time != 0:
        if Dash_time.hour < work_start_hour:
            Dash_time = Dash_time.replace(hour=work_start_hour, minute=0, second=0, microsecond=0)

        if Dash_time + run_time <= end_of_day:
            Dash_time += run_time
            run_time = timedelta(0)
        else:
            run_time -= (end_of_day - Dash_time)
            Dash_time = end_of_day
        
        if Dash_time.hour >= work_end_hour:
            Dash_time = Dash_time.replace(hour=work_start_hour, minute=0, second=0, microsecond=0) + timedelta(days=1)
            end_of_day = Dash_time.replace(hour=work_end_hour, minute=0, second=0, microsecond=0)
        
        current_day = Dash_time.strftime('%A')
        if current_day == "Saturday":
            Dash_time += timedelta(days=2)
        elif current_day == "Sunday":
            Dash_time += timedelta(days=1)
        
        if Dash_time.strftime('%A') == "Saturday":
            Dash_time += timedelta(days=2)
        elif Dash_time.strftime('%A') == "Sunday":
            Dash_time += timedelta(days=1)

        
            
        
    update_data_runtime()

    current_time = Dash_time.strftime('%H:%M:%S')
    current_date = Dash_time.strftime('%d-%m-%Y')
    current_day = Dash_time.strftime('%A')
    
    return current_time, current_date, current_day



@app.callback(
    Output('main-graph', 'figure'),
    [Input('plot-dropdown', 'value'), Input('interval-component-data', 'n_intervals')]
)
def update_graph(selected_plot,n):
    df = fetch_data()
    if df.empty:
        return px.line(title='No Data Available')

    # Process the DataFrame for each plot type
    if selected_plot=="Gantt Chart":
        # Convert 'Start Time' and 'End Time' columns to datetime
        df['Start Time'] = pd.to_datetime(df['Start Time'])
        df['End Time'] = pd.to_datetime(df['End Time'])

        # Convert 'Final Setup Time' to timedelta
        df['Final Setup Time'] = pd.to_timedelta(df['Final Setup Time'], unit='seconds', errors='coerce')

        # Create new DataFrame for plotting
        plot_data = []

        for _, row in df.iterrows():
            # Add the main component row
            plot_data.append({
                'Product Name': row['Product Name'],
                'Components': row['Components'],
                'Start Time': row['Start Time'],
                'End Time': row['End Time'],
                'Machine Number': row['Machine Number']
            })
            
            # Add the setup time row if it exists and is greater than zero
            if pd.notnull(row['Final Setup Time']) and row['Final Setup Time'] > pd.Timedelta(0):
                setup_start = row['End Time']
                setup_end = setup_start + row['Final Setup Time']
                plot_data.append({
                    'Product Name': row['Product Name'],
                    'Components': f"Final Setup {row['Components']}",
                    'Start Time': setup_start,
                    'End Time': setup_end,
                    'Machine Number': row['Machine Number']
                })

        plot_df = pd.DataFrame(plot_data)

        # Define specific colors for each component and final setup time
        color_discrete_map = {
            "C1": 'skyblue', 
            "C2": 'yellow', 
            "C3": 'salmon', 
            "C4": 'gold', 
            "C5": 'orchid',
            "Final Setup C1": 'lightgreen',
            "Final Setup C2": 'lightgreen',
            "Final Setup C3": 'lightgreen',
            "Final Setup C4": 'lightgreen',
            "Final Setup C5": 'lightgreen'
        }

        # Create the Gantt chart
        fig = px.timeline(plot_df, x_start='Start Time', x_end='End Time', y='Product Name', color='Components',
                        title='Real-Time 2D Gantt Chart', labels={'Components': 'Component'},
                        hover_data={'Machine Number': True, 'Start Time': '|%H:%M:%S'}, color_discrete_map=color_discrete_map)

        fig.update_layout(
            xaxis_title="Time",
            yaxis_title="Products",
            xaxis=dict(
                tickangle=45,
                tickformat="%Y-%m-%d %H:%M:%S",
                rangeslider=dict(visible=True),
                tickmode='linear'
            ),
            height=800,  # Adjust height for better readability
            width=1400,  # Adjust width for better readability
        )

        # Add machine IDs as text inside the rectangles
        for index, row in df.iterrows():
            if pd.notnull(row['Start Time']) and pd.notnull(row['End Time']):
                
                start_time = pd.to_datetime(row['Start Time'])
                end_time = pd.to_datetime(row['End Time'])
                duration = (end_time - start_time) / 2
                mid_time = start_time + duration
                fig.add_annotation(
                    x=mid_time.strftime("%Y-%m-%d %H:%M:%S"),
                    y=row['Product Name'],
                    text=f"{row['Machine Number']}<br>{row['Components']}",
                    showarrow=False,
                    font=dict(color='black', size=9),
                    align='center',
                    xanchor='center',
                    yanchor='middle'
                )

        # Save the figure as an HTML file and open it
        #pio.write_html(fig, 'gantt_chart.html', auto_open=True)

        

             
    elif selected_plot == "Utilization":
        df['Time Diff'] = df['Time Diff'].apply(time_to_timedelta2)
        df['Utilization'] = df['Time Diff'].apply(calculate_utilization)
        #print(df)
        # Convert Machine Number to categorical
        df['Machine Number'] = df['Machine Number'].astype(str)
        # Remove rows where Machine Number is 'OutSrc'
        df = df[df['Machine Number'] != 'OutSrc']

        df['Utilization %'] = (df['Utilization'] / 420) * 100
        fig = px.bar(df, x='Machine Number', y='Utilization %',color='Machine Number',
                     labels={'Utilization %': 'Utilization (%)', 'Machine Number': 'Machine'},
                     title='Utilization Percentage for Each Machine',color_discrete_sequence=['red', 'blue', 'green', 'orange', 'purple'])
        
        # Update y-axis to range from 0 to 100
        fig.update_yaxes(range=[0, 100])
    elif selected_plot == "Time Taken by each Machine":
        df['Time Diff'] = df['Time Diff'].apply(time_to_timedelta2)
        # Remove rows where Machine Number is 'OutSrc'
        df = df[df['Machine Number'] != 'OutSrc']
        total_running_time = df.groupby('Machine Number')['Time Diff'].sum().reset_index()
        y_ticks = pd.to_timedelta(range(0, int(total_running_time['Time Diff'].max().total_seconds()) + 1, 8000), unit='s')
        fig = px.bar(total_running_time, x='Machine Number', y='Time Diff',color='Machine Number',
                     labels={'Time Diff': 'Total Running Time (hh:mm:ss)', 'Machine Number': 'Machine'},
                     title='Total Running Time for Each Machine',color_discrete_sequence=['red', 'blue', 'green', 'orange', 'purple'])
        fig.update_layout(
            yaxis=dict(
                tickmode='array',
                tickvals=y_ticks,
                ticktext=[str(td)[7:] for td in y_ticks]
            )
        )
    elif selected_plot == "Time taken by each product":
        df['Time Diff'] = df['Time Diff'].apply(time_to_timedelta2)
        total_running_time_component = df.groupby(['Product Name', 'Components'])['Time Diff'].sum().reset_index()
        total_running_time_component['Product_Component'] = total_running_time_component['Product Name'] + ' - ' + total_running_time_component['Components']
        max_seconds = int(total_running_time_component['Time Diff'].max().total_seconds())
        y_ticks = pd.to_timedelta(range(0, max_seconds + 1, 7000), unit='s')
        fig = px.bar(total_running_time_component, x='Product_Component', y='Time Diff',
                     labels={'Time Diff': 'Total Running Time (hh:mm:ss)', 'Product_Component': 'Product - Component'},
                     title='Total Running Time for Each Product and Component')
        fig.update_layout(
            yaxis=dict(
                tickmode='array',
                tickvals=y_ticks,
                ticktext=[str(td)[7:] for td in y_ticks]
            ),
            xaxis_tickvals=total_running_time_component['Product_Component'],
            xaxis_ticktext=[f"{p.split(' - ')[0]}\n{p.split(' - ')[1]}" for p in total_running_time_component['Product_Component']]
        )
    elif selected_plot == "Wait Time":
        df['Wait Time'] = df['Wait Time'].apply(time_to_timedelta2)
        total_wait_time_component = df.groupby(['Product Name', 'Components'])['Wait Time'].sum().reset_index()
        total_wait_time_component['Product_Component'] = total_wait_time_component['Product Name'] + ' - ' + total_wait_time_component['Components']
        max_seconds = int(total_wait_time_component['Wait Time'].max().total_seconds())
        y_ticks = pd.to_timedelta(range(0, max_seconds + 1, 5000), unit='s')
        fig = px.bar(total_wait_time_component, x='Product_Component', y='Wait Time',
                     labels={'Wait Time': 'Total Wait Time (hh:mm:ss)', 'Product_Component': 'Product - Component'},
                     title='Total Wait Time for Each Product and Component')
        fig.update_layout(
            yaxis=dict(
                tickmode='array',
                tickvals=y_ticks,
                ticktext=[str(td)[7:] for td in y_ticks]
            ),
            xaxis_tickvals=total_wait_time_component['Product_Component'],
            xaxis_ticktext=[f"{p.split(' - ')[0]}\n{p.split(' - ')[1]}" for p in total_wait_time_component['Product_Component']]
        )
    elif selected_plot == "Idle Time":
        df['Idle Time'] = df['Idle Time'].apply(time_to_timedelta2)
        # Remove rows where Machine Number is 'OutSrc'
        df = df[df['Machine Number'] != 'OutSrc']
        total_ideal_time = df.groupby('Machine Number')['Idle Time'].sum().reset_index()
        y_ticks_1 = pd.to_timedelta(range(0, int(total_ideal_time['Idle Time'].max().total_seconds()) + 1, 15000), unit='s')
        fig = px.bar(total_ideal_time, x='Machine Number', y='Idle Time',
                     labels={'Idle Time': 'Total Idle Time (hh:mm:ss)', 'Machine Number': 'Machine'},
                     title='Total Idle Time for Each Machine',color_discrete_sequence=['red', 'blue', 'green', 'orange', 'purple'])
        fig.update_layout(
            yaxis=dict(
                tickmode='array',
                tickvals=y_ticks_1,
                ticktext=[str(td)[7:] for td in y_ticks_1],
                tickformat='%H:%M:%S'
            )
        )
    elif selected_plot == "Product Components Status":
        df['Status'] = df['Status'].apply(lambda x: str(x).strip() if x is not None else '')
        status_colors = {
            "InProgress_Outsource": "orange",
            "InProgress_In House": "red",
            "Completed_In House": "green",
            "Completed_Outsource": "blue",
        }
        fig = go.Figure()

        for product in df['Product Name'].unique():
            product_data = df[df['Product Name'] == product]
            for component in product_data['Components'].unique():
                component_data = product_data[product_data['Components'] == component]
                status = component_data['Status'].values[0]
                process_type = component_data['Process Type'].values[0]
                machine_number = component_data['Machine Number'].values[0]
                
                key = f"{status}_{process_type}"
                color = status_colors.get(key, "grey")
                fig.add_trace(go.Scatter(
                    x=[product],
                    y=[component],
                    mode='markers+text',
                    marker=dict(
                        color=color,
                        size=30,
                        symbol='square'
                    ),
                    text=[machine_number],
                    textposition='middle center',
                    name=f'{product} - {component}',
                    legendgroup=key,
                    showlegend=False
                ))

        # Create legend items manually, ensuring only 4 specific entries
        custom_legend_names = {
            "InProgress_Outsource": "Component Out for Outsource",
            "Completed_Outsource": "Component Back From Outsource",
            "InProgress_In House": "Component InProgress Inhouse",
            "Completed_In House": "Component Completed Inhouse"
        }

        for status_key, color in status_colors.items():
            legend_name = custom_legend_names.get(status_key, status_key.replace("_", " and "))
            fig.add_trace(go.Scatter(
                x=[None], y=[None],
                mode='markers',
                marker=dict(
                    color=color,
                    size=10,
                    symbol='square'
                ),
                legendgroup=status_key,
                showlegend=True,
                name=legend_name
            ))

        fig.update_layout(
            title='Status of Each Product Component',
            xaxis_title='Product',
            yaxis_title='Component',
            xaxis=dict(tickmode='array', tickvals=df['Product Name'].unique()),
            yaxis=dict(tickmode='array', tickvals=df['Components'].unique()),
            legend_title_text='Status and Process Type'
        )
    elif selected_plot=="Remaining Time":
        product_times = {}
            
        for product in df['Product Name'].unique():
            product_df = df[df['Product Name'] == product]
            
            total_time = product_df['Run Time (min/1000)'].sum()
            remaining_time = product_df[product_df['Status'] != 'Completed']['Run Time (min/1000)'].sum()
            
            product_times[product] = {
                'Total Time': total_time,
                'Remaining Time': remaining_time
            }

        time_df=pd.DataFrame(product_times).T.reset_index().rename(columns={'index': 'Product Name'})
        #print(time_df)


        # Calculate the completed time
        time_df['Completed Time'] = time_df['Total Time'] - time_df['Remaining Time']

        # Create a stacked horizontal bar chart
        fig = go.Figure()

        # Add trace for Completed Time
        fig.add_trace(go.Bar(
            y=time_df['Product Name'],
            x=time_df['Completed Time'],
            orientation='h',
            name='Completed Time',
            marker=dict(color='green'),
            text=time_df['Completed Time'],
            textposition='inside',
        ))

        # Add trace for Remaining Time
        fig.add_trace(go.Bar(
            y=time_df['Product Name'],
            x=time_df['Remaining Time'],
            orientation='h',
            name='Remaining Time',
            marker=dict(color='red'),
            text=time_df['Remaining Time'],
            textposition='inside',
        ))

        # Update layout
        fig.update_layout(
            barmode='stack',
            title='Total and Remaining Time for Each Product',
            xaxis_title='Time (min)',
            yaxis_title='Product Name',
            yaxis=dict(automargin=True),
            legend=dict(
                orientation='h',
                yanchor='bottom',
                y=1.02,
                xanchor='right',
                x=1
            ),
            margin=dict(l=0, r=0, t=50, b=0)  # Adjust margin as needed
        )

    return fig

if __name__ == '__main__':
    

    app.run_server(debug=True)
